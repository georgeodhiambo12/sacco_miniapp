<?php
session_start(); 
$servername = "localhost";
$username = "tenderso_home";
$password = "QMPch6bU7}7W";
$dbname = "tenderso_HOME";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    die("Unauthorized access! Only admins can view this page.");
}

// Handle form submission for adding a new member
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_member'])) {
    $member_name = $_POST['member_name'];
    $phone = $_POST['phone'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Insert the new member into the database
    $sql = "INSERT INTO members (member_name, phone, username, password, role) 
            VALUES ('$member_name', '$phone', '$username', '$password', '$role')";
    if ($conn->query($sql) === TRUE) {
        echo "New member added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Filter logic
$filter_name = '';
$filter_date_query = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['filter'])) {
    if (!empty($_POST['member_name'])) {
        $filter_name = $_POST['member_name'];
    }

    if (!empty($_POST['start_date']) && !empty($_POST['end_date'])) {
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];
        $filter_date_query = "AND p.date BETWEEN '$start_date' AND '$end_date'";
    }
}

// Fetch members for the filter dropdown
$members_query = "SELECT DISTINCT member_name FROM members";
$members_result = $conn->query($members_query);

// Fetch filtered payment data for admin view, ordered by member_name and period_week
$sql = "SELECT m.member_name, p.date, p.pay_date, p.time, p.period_week, p.amount, p.fine 
        FROM payments p 
        JOIN members m ON p.member_id = m.member_id
        WHERE m.member_name LIKE '%$filter_name%' $filter_date_query
        ORDER BY m.member_name, p.period_week";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - All Payments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logout-btn {
            background-color: #dc3545;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            margin-right: 20px;
        }

        .logout-btn:hover {
            background-color: #c82333;
        }

        .add-member-btn, .add-payment-btn, .back-btn {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            display: inline-block;
            margin-bottom: 20px;
        }

        .add-member-btn:hover, .add-payment-btn:hover, .back-btn:hover {
            background-color: #218838;
        }

        .filter-form {
            display: inline-block;
            margin-right: 20px;
        }

        .filter-form input[type="text"],
        .filter-form input[type="date"],
        .filter-form select {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 10px;
        }

        .filter-form button {
            padding: 8px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .filter-form button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .no-records {
            text-align: center;
            margin-top: 20px;
            color: red;
        }

        .subtotal-row {
            font-weight: bold;
            background-color: #f0f0f0;
        }

        .grand-total {
            font-weight: bold;
            background-color: #d1ecf1;
        }

        .green-text {
            color: green; /* Styling for the total amounts */
        }

        .red-text {
            color: red; /* Fine amounts except 0 */
        }

        .black-text {
            color: black; /* Fine amount 0 */
        }

        .add-member-form {
            display: none;
            margin-top: 20px;
            padding: 20px;
            border: 1px solid #ccc;
            background-color: #fff;
            border-radius: 5px;
        }

        .add-member-form input {
            padding: 10px;
            margin: 5px;
            border-radius: 4px;
            border: 1px solid #ddd;
            width: 100%;
        }

        .add-member-form button {
            padding: 10px;
            margin: 10px 0;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>

    <script>
        function toggleForm() {
            var form = document.getElementById("addMemberForm");
            if (form.style.display === "none") {
                form.style.display = "block";
            } else {
                form.style.display = "none";
            }
        }
    </script>
</head>
<body>
    <div class="top-bar">
        <h1>Admin Dashboard - All Payments</h1>
        <!-- Logout button aligned to the right -->
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

    <!-- Add Payment and Add Member button -->
    <a href="add_payment.php" class="add-payment-btn">Add Payment</a>
    <a href="javascript:void(0);" class="add-member-btn" onclick="toggleForm()">Add New Member</a>
    <a href="view_all_payments.php" class="back-btn">Back to Home</a>

    <!-- Filter Form -->
    <div class="filter-form">
        <form action="view_all_payments.php" method="POST">
            <!-- Filter by name -->
            <label for="member_name">Filter by Name:</label>
            <select name="member_name" id="member_name">
                <option value="">-- All Members --</option>
                <?php
                while ($row_member = $members_result->fetch_assoc()) {
                    echo "<option value='" . $row_member['member_name'] . "'>" . $row_member['member_name'] . "</option>";
                }
                ?>
            </select>

            <!-- Filter by calendar (date range) -->
            <label for="start_date">Start Date:</label>
            <input type="date" id="start_date" name="start_date">

            <label for="end_date">End Date:</label>
            <input type="date" id="end_date" name="end_date">

            <!-- Submit button -->
            <button type="submit" name="filter">Filter</button>
        </form>
    </div>

    <!-- Form to add a new member, hidden by default -->
    <div id="addMemberForm" class="add-member-form">
        <h2>Add New Member</h2>
        <form action="view_all_payments.php" method="POST">
            <input type="text" name="member_name" placeholder="Member Name" required>
            <input type="text" name="phone" placeholder="Phone Number" required>
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <select name="role" required>
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select>
            <button type="submit" name="add_member">Add Member</button>
        </form>
    </div>

    <!-- Existing table display for payments (no change to this part) -->
    <?php
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr>
                <th>Member No.</th>
                <th>Member Name</th>
                <th>Date</th>
                <th>Pay Date</th>
                <th>Time</th>
                <th>Period (Week)</th>
                <th>Amount</th>
                <th>Fine</th>
                <th>Total</th>
              </tr>";

        $current_member = '';
        $member_total_amount = 0;
        $member_total_fine = 0;
        $member_count = 0;  // Initialize member counter
        $grand_total_amount = 0; // Grand total for all amounts
        $grand_total_fine = 0;   // Grand total for all fines

        while ($row = $result->fetch_assoc()) {
            $total = $row['amount'] + $row['fine'];

            if ($row['member_name'] != $current_member && $current_member != '') {
                // Display the subtotal for the previous member
                $member_total = $member_total_amount + $member_total_fine;
                echo "<tr class='subtotal-row'>
                        <td colspan='6'>Subtotal for $current_member</td>
                        <td class='green-text'>" . number_format($member_total_amount, 2) . "</td>
                        <td class='" . ($member_total_fine == 0.00 ? "black-text" : "red-text") . "'>" . number_format($member_total_fine, 2) . "</td>
                        <td class='green-text'>" . number_format($member_total, 2) . "</td>
                      </tr>";

                // Reset totals for the new member
                $member_total_amount = 0;
                $member_total_fine = 0;
            }

            // Update current member and totals
            if ($row['member_name'] != $current_member) {
                $current_member = $row['member_name'];
                $member_count++; // Increment member counter
                $show_member_number = true;  // Only show member number on first row of each member
            } else {
                $show_member_number = false; // Hide member number for subsequent rows
            }

            $member_total_amount += $row['amount'];
            $member_total_fine += $row['fine'];

            // Add to grand totals
            $grand_total_amount += $row['amount'];
            $grand_total_fine += $row['fine'];

            // Display payment details
            echo "<tr>";
            echo $show_member_number ? "<td>" . $member_count . "</td>" : "<td></td>"; // Show member number only on first row
            echo "<td>" . $row['member_name'] . "</td>
                    <td>" . $row['date'] . "</td>
                    <td>" . $row['pay_date'] . "</td>
                    <td>" . $row['time'] . "</td>
                    <td>" . $row['period_week'] . "</td>
                    <td class='green-text'>" . number_format($row['amount'], 2) . "</td>
                    <td class='" . ($row['fine'] == 0.00 ? "black-text" : "red-text") . "'>" . number_format($row['fine'], 2) . "</td>
                    <td class='green-text'>" . number_format($total, 2) . "</td>
                  </tr>";
        }

        // Display the last member's subtotal
        if ($current_member != '') {
            $member_total = $member_total_amount + $member_total_fine;
            echo "<tr class='subtotal-row'>
                    <td colspan='6'>Subtotal for $current_member</td>
                    <td class='green-text'>" . number_format($member_total_amount, 2) . "</td>
                    <td class='" . ($member_total_fine == 0.00 ? "black-text" : "red-text") . "'>" . number_format($member_total_fine, 2) . "</td>
                    <td class='green-text'>" . number_format($member_total, 2) . "</td>
                  </tr>";
        }

        // Display grand totals for all members
        $grand_total = $grand_total_amount + $grand_total_fine;
        echo "<tr class='grand-total'>
                <td colspan='6'>Grand Total for All Members</td>
                <td class='green-text'>" . number_format($grand_total_amount, 2) . "</td>
                <td class='" . ($grand_total_fine == 0.00 ? "black-text" : "red-text") . "'>" . number_format($grand_total_fine, 2) . "</td>
                <td class='green-text'>" . number_format($grand_total, 2) . "</td>
              </tr>";

        echo "</table>";
    } else {
        echo "<p class='no-records'>No payment records found.</p>";
    }

    $conn->close();
    ?>
</body>
</html>
